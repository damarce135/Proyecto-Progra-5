﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DO.Objects
{
    public class Solicitud
    {

        public int IdSolicitud { get; set; }
        public string Asunto { get; set; }
        public string Descripcion { get; set; }

    }
}
