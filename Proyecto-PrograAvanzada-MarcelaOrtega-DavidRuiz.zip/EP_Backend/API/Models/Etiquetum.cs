﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace API.Models
{
    public class Etiquetum
    {
        public int IdEtiqueta { get; set; }
        public string NombreEtiqueta { get; set; }
    }
}
